package com.ers.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ers.model.Employee;
import com.ers.service.EmployeeRegistrationService;
import com.ers.service.EmployeeRegistrationServiceImpl;


/**
 * Servlet implementation class EmployeeLoginServlet
 */
@WebServlet("/employee-login")
public class EmployeeLoginServlet extends HttpServlet {
	private Integer Id;
	private EmployeeRegistrationService sld=new EmployeeRegistrationServiceImpl();
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
			String employeeId=request.getParameter("Id");
			String password=request.getParameter("password");
			Employee e=sld.login(employeeId, password);
			
			RequestDispatcher rd=null;
			
			if(e==null) {
				rd=request.getRequestDispatcher("/ERS/login.html");
			}else {
				System.out.println(e.getType());
				if(e.getType().equalsIgnoreCase("manager"))
					rd=request.getRequestDispatcher("/ERS/managerDashboard.html");
				else
					rd=request.getRequestDispatcher("/ERS/employeeDashboard.html");
				rd.forward(request, response);
			}
				
	}	
		


	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeLoginServlet() {
    	
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	/*protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	} */

}
